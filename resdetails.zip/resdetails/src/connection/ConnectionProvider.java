package connection;

public interface ConnectionProvider {
	String dbname = "root";
	String dbpassword = "password";
	String dburl = "jdbc:mysql://localhost:3307/zomato_details";


}
